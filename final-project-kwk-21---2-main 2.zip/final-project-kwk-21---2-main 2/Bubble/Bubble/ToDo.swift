//
//  ToDo.swift
//  Bubble
//
//  Created by Scholar on 8/2/21.
//

import UIKit

class ToDo {
  var name = ""
  var important = false
}
